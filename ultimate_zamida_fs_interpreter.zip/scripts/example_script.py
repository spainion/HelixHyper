"""Example script used in CLI tests."""

def run(args):
    """Return a simple greeting for demonstration purposes."""
    return "Hello from example script"