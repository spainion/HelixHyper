"""Stub script to export a graph to JSON with 3D coordinates (unused)."""

from __future__ import annotations

from typing import List


def run(argv: List[str]) -> None:
    # No‑op stub for tests; real implementation omitted.
    pass